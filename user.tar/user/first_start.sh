#!/bin/bash

nitrogen ~/Desktop/debian_city.png --set-auto

rm ~/.config/autostart/first-start.desktop
rm ~/first_start.sh